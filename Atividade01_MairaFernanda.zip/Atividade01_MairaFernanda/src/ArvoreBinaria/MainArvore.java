package ArvoreBinaria;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MainArvore {
    public static void main(String[] args) {
        ArvoreBinaria arvore = new ArvoreBinaria();

        try {
            BufferedReader reader = new BufferedReader(new FileReader("src/Entrada/exec"));
            String linha;

            while ((linha = reader.readLine()) != null) {
                String[] comando = linha.split(";");

                switch (comando[0]) {
                    case "INSERIR":
                        try {
                            int chave = Integer.parseInt(comando[1]);
                            arvore.inserir(chave, comando[2]);
                        } catch (NumberFormatException e) {
                            System.err.println("Erro: Chave não é um número inteiro válido, Reveja o arquivo exec");
                        }
                        break;
                    case "REMOVER":
                        try {
                            int chaveRemover = Integer.parseInt(comando[1]);
                            arvore.remover(chaveRemover);
                        } catch (NumberFormatException e) {
                            System.err.println("Erro: Chave não é um número inteiro válido. Reveja o arquivo exec");
                        }
                        break;
                    case "IMPRIMIR":
                        arvore.imprimir();
                        break;
                    case "BUSCAR":
                        try {
                            int chaveBuscar = Integer.parseInt(comando[1]);
                            No resultado = arvore.buscar(chaveBuscar);
                            if (resultado != null) {
                                System.out.println("Elemento encontrado: " + resultado.valor);
                            } else {
                                System.out.println("Elemento não encontrado.");
                            }
                        } catch (NumberFormatException e) {
                            System.err.println("Erro: Chave não é um número inteiro válido. Reveja o arquivo exec");
                        }
                        break;
                    default:
                        System.out.println("Comando inválido: " + comando[0]);
                }
            }

            reader.close();
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }
    }
}
