package ArvoreBinaria;

public class No {
    int chave;
    String valor;
    No esquerda;
    No direita;

    public No(int chave, String valor) {
        this.chave = chave;
        this.valor = valor;
        this.esquerda = null;
        this.direita = null;
    }
}
