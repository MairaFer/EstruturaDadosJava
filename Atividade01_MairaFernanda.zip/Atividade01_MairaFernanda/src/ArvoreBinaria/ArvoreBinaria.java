package ArvoreBinaria;

public class ArvoreBinaria {
    private No raiz;

    public void inserir(int chave, String valor) {
        raiz = inserirRecursivamente(raiz, chave, valor);
    }

    private No inserirRecursivamente(No no, int chave, String valor) {
        if (no == null) {
            return new No(chave, valor);
        }

        if (chave < no.chave) {
            no.esquerda = inserirRecursivamente(no.esquerda, chave, valor);
        } else if (chave > no.chave) {
            no.direita = inserirRecursivamente(no.direita, chave, valor);
        } else {
            throw new IllegalArgumentException("Chave já existe na árvore.");
        }

        return no;
    }

    public No buscar(int chave) {
        return buscarRecursivamente(raiz, chave);
    }

    private No buscarRecursivamente(No no, int chave) {
        if (no == null || no.chave == chave) {
            return no;
        }

        if (chave < no.chave) {
            return buscarRecursivamente(no.esquerda, chave);
        }

        return buscarRecursivamente(no.direita, chave);
    }

    public void remover(int chave) {
        raiz = removerRecursivamente(raiz, chave);
    }


    private No removerRecursivamente(No no, int chave) {
        if (no == null) {
            return null;
        }

        if (chave < no.chave) {
            no.esquerda = removerRecursivamente(no.esquerda, chave);
        } else if (chave > no.chave) {
            no.direita = removerRecursivamente(no.direita, chave);
        } else {

            if (no.esquerda == null) {
                return no.direita;
            } else if (no.direita == null) {
                return no.esquerda;
            }

            no.chave = encontrarMenorValor(no.direita);
            no.direita = removerRecursivamente(no.direita, no.chave);
        }

        return no;
    }

    private int encontrarMenorValor(No no) {
        return no.esquerda == null ? no.chave : encontrarMenorValor(no.esquerda);
    }

    public void imprimir() {
        imprimirRecursivamente(raiz);
    }

    private void imprimirRecursivamente(No no) {
        if (no != null) {
            imprimirRecursivamente(no.esquerda);
            System.out.println("Chave: " + no.chave + ", Valor: " + no.valor);
            imprimirRecursivamente(no.direita);
        }
    }
}
