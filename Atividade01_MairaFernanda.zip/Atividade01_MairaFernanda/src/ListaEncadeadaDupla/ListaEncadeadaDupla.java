package ListaEncadeadaDupla;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ListaEncadeadaDupla {
    private class No {
        Object dado;
        No proximo;
        No anterior;

        public No(Object dado) {
            this.dado = dado;
            this.proximo = null;
            this.anterior = null;
        }
    }

    private No inicio;
    private No fim;

    public void inserir(Object dado) {
        No novoNo = new No(dado);
        if (inicio == null) {
            inicio = novoNo;
            fim = novoNo;
        } else {
            fim.proximo = novoNo;
            novoNo.anterior = fim;
            fim = novoNo;
        }
    }

    public boolean buscar(Object dado) {
        No atual = inicio;
        while (atual != null) {
            if (atual.dado.equals(dado)) {
                return true;
            }
            atual = atual.proximo;
        }
        return false;
    }

    public boolean remover(Object dado) {
        No atual = inicio;
        while (atual != null) {
            if (atual.dado.equals(dado)) {
                if (atual == inicio) {
                    inicio = inicio.proximo;
                    if (inicio != null) {
                        inicio.anterior = null;
                    } else {
                        fim = null;
                    }
                } else if (atual == fim) {
                    fim = fim.anterior;
                    fim.proximo = null;
                } else {
                    atual.anterior.proximo = atual.proximo;
                    atual.proximo.anterior = atual.anterior;
                }
                return true;
            }
            atual = atual.proximo;
        }
        return false;
    }

    public void imprimir() {
        No atual = inicio;
        while (atual != null) {
            System.out.println(atual.dado);
            atual = atual.proximo;
        }
    }
    public void carregarDados(String nomeArquivo) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(nomeArquivo));
        String linha;
        while ((linha = reader.readLine()) != null) {
            inserir(linha);
        }
        reader.close();
    }
}
