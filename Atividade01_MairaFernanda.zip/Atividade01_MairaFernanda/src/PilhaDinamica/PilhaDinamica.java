package PilhaDinamica;

public class PilhaDinamica {
    private class No {
        Object dado;
        No proximo;

        public No(Object dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }

    private No topo;

    public void inserir(Object dado) {
        No novoNo = new No(dado);
        novoNo.proximo = topo;
        topo = novoNo;
    }

    public Object remover() {
        if (topo == null) {
            return null;
        }
        Object dadoRemovido = topo.dado;
        topo = topo.proximo;
        return dadoRemovido;
    }

    public boolean estaVazia() {
        return topo == null;
    }

    public void imprimir() {
        No atual = topo;
        while (atual != null) {
            System.out.println(atual.dado);
            atual = atual.proximo;
        }
    }

    public boolean buscar(Object dado) {
        No atual = topo;
        while (atual != null) {
            if (atual.dado.equals(dado)) {
                return true;
            }
            atual = atual.proximo;
        }
        return false;
    }
}
