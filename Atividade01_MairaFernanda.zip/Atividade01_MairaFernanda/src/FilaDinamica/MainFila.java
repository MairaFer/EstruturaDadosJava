package FilaDinamica;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MainFila {
    public static void main(String[] args) {
        FilaDinamica fila = new FilaDinamica();

        try {
            BufferedReader reader = new BufferedReader(new FileReader("src/Entrada/exec"));
            String linha;

            while ((linha = reader.readLine()) != null) {
                String[] comando = linha.split(";");

                switch (comando[0]) {
                    case "INSERIR":
                        fila.inserir(comando[1]);
                        break;
                    case "REMOVER":
                        fila.remover();
                        break;
                    case "IMPRIMIR":
                        fila.imprimir();
                        break;
                    case "BUSCAR":
                        boolean encontrado = fila.buscar(comando[1]);
                        if (encontrado) {
                            System.out.println("Elemento encontrado: " + comando[1]);
                        } else {
                            System.out.println("Elemento não encontrado: " + comando[1]);
                        }
                        break;
                    default:
                        System.out.println("Comando inválido: " + comando[0]);
                }
            }

            reader.close();
        } catch (IOException e) {
            System.err.println("Erro ao ler o arquivo: " + e.getMessage());
        }
    }
}
