package FilaDinamica;

public class FilaDinamica {
    private class No {
        Object dado;
        No proximo;

        public No(Object dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }

    private No inicio;
    private No fim;

    public void inserir(Object dado) {
        No novoNo = new No(dado);
        if (inicio == null) {
            inicio = novoNo;
            fim = novoNo;
        } else {
            fim.proximo = novoNo;
            fim = novoNo;
        }
    }

    public Object remover() {
        if (inicio == null) {
            return null;
        }
        Object dadoRemovido = inicio.dado;
        inicio = inicio.proximo;
        if (inicio == null) {
            fim = null;
        }
        return dadoRemovido;
    }

    public boolean estaVazia() {
        return inicio == null;
    }

    public void imprimir() {
        No atual = inicio;
        while (atual != null) {
            System.out.println(atual.dado);
            atual = atual.proximo;
        }
    }

    public boolean buscar(Object dado) {
        No atual = inicio;
        while (atual != null) {
            if (atual.dado.equals(dado)) {
                return true;
            }
            atual = atual.proximo;
        }
        return false;
    }
}
